
/**
	 * @author Brian Coppola
	 * This is the definition for the Key list
	 * 
	 * The methods in this are: clear, findIndex, add, remove, retrieve, 
	 * is empty, is full, print, getCount, calcTotal
	 */

public class KeyListCoppola
{
	
	/**
	 * Instance variable for the list of objects
	 */
	private ItemCoppola myList [];
	
	/**
	 * Instance variable for the Size
	 */
	private int mySize;

	/**
	 * The default constructor
	 */
	public KeyListCoppola()
	{
		
		myList = new ItemCoppola [20];
		mySize = 0;
		
	}//null constructor
	
	/**
	 * Clears the list 
	 */
	public void clear ()
	{
		mySize = 0;
	}//clear
	
	/**
	 * Finds the index of item that matches 
	 * @param keyvalue the incoming name for the item
	 * @return index that has the same name as the keyvalue or just returns -1
	 */
	private int findIndex(String keyvalue)
	{
		//Initializes first variable
		int index = -1;
		
		
		for (int count = 0; count < mySize; count++)
		{
			//finds if the keyValue is equal to the name
			if(myList[count].getName().compareToIgnoreCase(keyvalue) == 0)
				
				//Saves the index
				index = count;
		}//for 
		
		return index;
	}//findIndex
	
	/**
	 * Adds Items into the list
	 * @param product the new item that is being added into the list
	 * @return a boolean that tells the user if the item has been added
	 */
	public boolean add(ItemCoppola  product)
	{
		//Initializes variables
		boolean room = false, found = false;
		int location = 0;

		//finds if the item exists
		int exist = findIndex(product.getName());
		
		//if find returns -1
		if(exist == -1)	
		{
		//Find the index where product should be added
			while (found == false && location < mySize)
			{
				//Sees if the product name is greater than the location name 
				if (product.getName().compareToIgnoreCase(myList[location].getName()) < 0 ) 
				{
					found = true;
				}//if
				else location++;
			}//while 
			
			//Loops until the count is less than the count 
			for(int count = mySize -1; count >= location ;count--)
			{
				//Shifts everything in the list the place ahead of it
				myList[count +1]= myList[count];
			}//for
				room = true;
				
				//Sets the product to the correct place in the list
				myList[location] = product;
				//Increments Size
				mySize++;
			
		}//if
			return room;
	
	}//add
	
	/**
	 * Deletes a desired item
	 * @param keyvalue the user's desired item to delete
	 * @return a boolean telling the user if the item has been deleted
	 */
	public boolean remove(String keyvalue)
	{
		//Initialize the local variable
		boolean delete = false;
		
		//Loops through all the objects in the list
		for (int count = 0; mySize > count; count++)
		{
			//finds if the item exists in the list
			if(keyvalue.compareToIgnoreCase(myList[count].getName()) == 0)
					delete = true;
		}//for
		
		if(delete)
		{
			//gets the index of the item
			int location = findIndex (keyvalue);
			
			//loops through the item's index to the Size-1
			for (int counter = location; counter < mySize - 1 ; counter++)
			{
				//Shifts everything past the location closer to the left of the list 
				myList[counter] = myList[counter + 1];
			}//for
		    
			// decrements size
			mySize--;
		}//if
		return delete;
	}//remove
	/**
	 * Tells the user about the item they entered 
	 * @param find the value that the user is looking for
	 * @return the item that was searched for and its to String will be printed in main
	 */
	public ItemCoppola retrieve (String find)
	{
		//Initializes local variables
		boolean found = false;
		int index = -1;
		
		
		for (int count = 0; mySize > count; count++)
		{
			//finds the item in the list 
			if(find.compareToIgnoreCase(myList[count].getName()) == 0)
			{
				//save location
				index = count;
				found = true;
			}//if
			
		}//for
		
		if (found)
		{
			return myList[index]; 
		}//if
		else 
			return null;
	}//retrieve
	/**
	 * determines if the list is empty 
	 * @return a boolean that tells the user if the list is empty in main
	 */
	public boolean isEmpty()
	{
		//Initializes the boolean
		boolean empty = false;
		
		//Finds out if the list is empty
		if(mySize == 0)
			empty = true;
		
		return empty;
	}//isEmpty
	
	/**
	 * determines if the list is full
	 * @return a boolean that tells the user if the list is full in the main
	 */
	public boolean isFull()
	{
		//Initializes
		boolean full = false;
			//Finds out if the list is full 
			if (mySize == 20)
				full = true;
		return full;
	}//isFull
	
	/**
	 * Prints out everything in the list
	 */
	public void print()
	{
		//Loops until everything is printed in the list
		for(int count = 0; mySize > count;  count++)
		{
			System.out.println(myList[count].toString());
		}//for
	}//print
	
	/**
	 * Outputs the amount of items in the list 
	 * @return the number of items in the list
	 */
	public int getCount()
	{
		int cart = 0;
		
		for (int count = 0; mySize > count; count++)
		{
			//Accumulates everything in the list
			cart += myList[count].getQuant();
		}//for
		
		return cart;
	}//getCount
	
	/**
	 * Calculates the total cost in the list 
	 * @return the total cost of everything in the list
	 */
	public double calcTotal()
	{
		//Initializes the local variables
		double sum = 0;
		
		for (int count = 0; mySize > count; count++)
		{
			//Accumulates all the prices in the list multiplied by their Quantities
			sum += myList[count].getQuant()* myList[count].getPrice();
			
		}//for
		return sum;
	}//calcTotal
	
	
}//KeyListCoppola
