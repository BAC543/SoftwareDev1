//Brian Coppola
//Due Feb 25
//Purpose to master methods in java
//Inputs- Customer ID, Name, Songs ordered, Length of Each Song, genres
//Outputs-ID, Name, Songs Ordered, Total cost of Songs, Service Charge, and Total Amount Due 
//Certify- I certify that this was completely my own work, but I discussed it with Alex.

import java.text.DecimalFormat;
import java.util.Scanner;

public class MusicOrderesCoppola 
{
	//Allows us to use the keyboard for all methods within the class
	static Scanner keyboard = new Scanner(System.in);
	
	//formats output within all methods of the class
	static DecimalFormat moneyStyle = new DecimalFormat("$0.00");
	
public static void main(String[]args)
	{
		
		
		//Declare variables
		int id = 1, songs = -1, people = 0, maxIndex = 0, minIndex = 0;
		String name;
		double songTotal = 0.0, serviceCharge = 0.0, price = 0.0, maxValue = Integer.MIN_VALUE, minValue = Integer.MAX_VALUE, finalTotal = 0.0, average = 0.0;
		
			//verifies the id number
			while(!(id >= 1000 && id <= 9999) && id != 0)
			{
				System.out.println("Please enter in your Customer ID. <1000 - 9999 incluive and hit 0 to quit>");
				id = keyboard.nextInt();
			}//while
			
			//Loop terminates when ID is 0
			while (id != 0)
			{
			
				//User inputs their name
				System.out.println("Please enter your name.");
				name = keyboard.next();
				
				
				
				do
				{
					System.out.println("Please enter the amount of songs ordered.");
					songs = keyboard.nextInt();
				}//do
				//verifies the number of songs the user has entered until it is greater than 0
				while(songs < 0);
				
				
				//Calculates the cost of the songs
				songTotal = chooseSongs (songs);
		
				//Calculates the user's service charge 
				serviceCharge = calcServiceCharge(songTotal,songs);
				
				//Calculates the Total price including tax
				price = calcTotalDue(songTotal, serviceCharge);
				
				
				//Saves the data of the customer who paid the most
				if (price >  maxValue)
				{
					maxValue = price;
					maxIndex = id;
				}//if
				
				//Saves the data of the customer who paid the least 
				if (price < minValue)
				{
					minValue = price;
					minIndex = id;
				}//if
				
				
				//Outputs all the user's information
				outputResults(name,id, songs, songTotal, serviceCharge, price);
				
				
				do
				{
					//Makes the user input the next Customer ID within the loop
					System.out.println("Please enter in your Customer ID. <1000 - 9999 incluive and hit 0 to quit>");
					id = keyboard.nextInt();
				}//do
				while(!(id >= 1000 && id <= 9999) && id != 0);
				
				//accumulates each user's payment
				finalTotal += price;
				
				//counts the number of times looped
				people ++;
				
			}//while
			
			//if looped through zero times no information will be shown
			if (people == 0)
				System.out.println("Looks like we are done here");
			else
			{
				//Calculates the average price of the users
				average = finalTotal / people;
				
				//prints out general information for all customers
				System.out.println("");
				System.out.println("Number of customers processed: "+ people);
				System.out.println("ID "+ maxIndex +" paid the most");
				System.out.println("Highest price: "+moneyStyle.format(maxValue));
				System.out.println("ID " + minIndex +" paid the least");
				System.out.println("Lowest price: "+ moneyStyle.format(minValue));
				System.out.println("Total amount of all music purchased: "+ moneyStyle.format(finalTotal));
				System.out.println("Average: "+ moneyStyle.format(average));
				
			}//else
			
	}//main

//Choose Songs
//Parameters- number of songs
//Purpose- Calculates the total cost of all the songs an individual user has purchased
//Returns the total
public static double chooseSongs (int songNum)
	{
		
		//declares variables within the method
		int songLength = 0;
		String genre = "????";
		char genreChar = '?';
		double total = 0.0;
		double cost = 0.0;
		
		//Loops for until information is entered for each individual song
		for (int count = 0; songNum > count; count++)

		{
			do
				{
				//Keeps track of what song number the user is entering
				System.out.println("How long is song number " + (count + 1) + " in seconds <song must be inbetween 1-6000 seconds inclusive> ");
				songLength = keyboard.nextInt();
				}//do loop verifies songLength
				while (!(songLength>=1 && songLength<= 6000));
			
			do
			{
			//User enters a string into genre
			System.out.println("Enter the genre of the song. < p = pop  r =rap  c=country  g=gospel o = other");
			genre = keyboard.next();
			
			// grabs the first character in the string
			genreChar = genre.charAt(0);
			//Forces the character to be lowercase
			genreChar = Character.toLowerCase(genreChar);
			
			}//do
			//Checks if the user entered valid input
			while (genreChar !='p' && genreChar != 'r' && genreChar !='c' && genreChar != 'g' && genreChar !=  'o');
			
			//Calculates the cost for each song
			switch (genreChar)
			{
			case 'p':
				cost = .004 * songLength;
				break;
			case 'r':
				cost = .0054 * songLength;
				break;
			case 'c':
				cost = .0019 * songLength;
				break;
			case 'g':
				cost = .003 * songLength;
				break;
			case 'o':
				cost = .0025 * songLength;
				break;
			default:
				break;
				
				
			}//switch
			
			//accumulates the total cost of each song
			total += cost;
			
		}//for	
		
		// returns the total song price
		return total;
		
	}//chooseSongs

//Calculate Service Charge
//Purpose- Calculates the Service Charge
//Parameters- total, number of Songs
//Returns- Service Charge
public static double calcServiceCharge (double total, int num)
	{
		//initializes variables within the method
		double service = 0.0;
		
		//Calculates the service charge based on the number of songs
		if (num >= 1 && num <= 4)
			service = total * .16;
		
			else if (num <= 9)
				service = total * .13;
		
				 else if (num <= 15)
					service = total *  .1;
		
					 else if (num >= 16)
						service = total * .06;
					 		
		//returns the service charge 
		return service;
	}//calcServiceCharge

//Calculates the Total Due
//Purpose- finds the total amount an individual customer owes
//Parameters- the cost of all songs and the service charge
//returns the final price
public static double calcTotalDue(double totalCost, double serCharge)
	{
		//initializes the variable within the method
		double totalprice = 0.0;
		
		//Calculate the total price by adding up the total cost of the songs, service charge and tax
		totalprice = totalCost + serCharge +((totalCost + serCharge)* .07);
		
		//returns the total price to main
		return totalprice;
		
	}//calcTotalDue

//Outputs Results
//Purpose- Outputs all of the user's information
//Parameters- name, id, number of songs, price, service charge, and total price
//returns- none
public static void outputResults(String customerName, int customerId,int numOfSongs, double songPrice, double serviceCost, double allDue)
	
	{
	//Tells the user that there's no data when no songs are ordered
	if(numOfSongs == 0)
		
		{
		System.out.println("");
		System.out.println("This customer didn't purchse anything");
		System.out.println("");
		}//if
		
		
	else
			{
			System.out.println("Name : "+ customerName );
			System.out.println("Customer ID: "+ customerId);
			System.out.println("Songs Ordered: "+ numOfSongs);
			System.out.println("Total price of the songs: "+ moneyStyle.format(songPrice));
			System.out.println("Service Charge: "+ moneyStyle.format(serviceCost));
			System.out.println("Total Due: "+ moneyStyle.format(allDue));
			System.out.println("");
			
			}//else
		
	}//outputResults

}//MusicOrdersCoppola
