//Brian Coppola
//Prog 1
//Due Feb 11th before 1:30 PM
//Purpose- Calculates your net pay
//Inputs- lastname, firstname, hours worked, pay rate,
//Outputs- fullname, hours worked, pay rate, gross wages, taxes owed, and net pay
//I certify that this was completley my own work

//Imports all Classes 
import java.util.*;
import java.text.*;
public class PayCalculaotrCoppola 
{

public static void main(String[] args)
    {
	Scanner keyboard = new Scanner(System.in); //define the keyboard
	
	DecimalFormat moneyStyle = new DecimalFormat("$0.00");
	
	//initialzing variables
	String lastname;
	String firstname;
	int hours;
	double rate;
	double gross;
	int extra;
	double taxrate;
	double owed;
	double net;
	
	gross = 0;
	taxrate = 0;
	
	//user enters in data
	System.out.println("Enter your last name.");
	lastname = keyboard.next();
	
	System.out.println("Enter your first name.");
	firstname = keyboard.next();
	
	System.out.println("Enter the amount of hours you worked.");
	hours = keyboard.nextInt();
	
	System.out.println("Enter your pay rate");
	rate = keyboard.nextDouble();
	
	//Calculates Extra hours 
	extra = hours - 40;
	
	//Calculates the gross pay
	if (hours <= 40)
	{
		gross = rate * hours;
	}//if
	else if (hours > 40 && hours < 50)
		{
			gross = (40 * rate) + (extra *(rate*1.5));
		}//if
		else if (hours >= 50)
			{
				gross = (40 * rate) + (extra * (rate * 2));
			}//if
	//Calculates the taxes owed
	if (gross <= 200)
	{
		taxrate = 0;
	}//if
	else if (gross > 200 && gross <=1000)
		{
			taxrate = .1;
		}//if
		else if (gross > 1000 && gross <= 2250)
			{
				taxrate = .22;
			}//if
			else if (gross > 2250)
					{
						taxrate = .31;
					}//if
	
	//Calculates taxes owed
	owed = taxrate * gross;
	
	//Calulates net pay
	net = gross - owed;
	
	//Sends user's output
	System.out.println(firstname +" "+ lastname);
	System.out.println("You worked "+ hours +" hours");
	System.out.println("Your pay rate was " + moneyStyle.format(rate));
	System.out.println("Your gross pay is "+ moneyStyle.format(gross));
	System.out.println("You owe "+moneyStyle.format(owed) +" in taxes");
	System.out.println("Your net pay is "+moneyStyle.format(net));
    }//main
}//Pay Calculator
